import React, { useState } from "react";
import { Button } from "../components/ui/button";
import { Input } from "../components/ui/input";
import { Label } from "../components/ui/label";
import { RTSData } from "../App";

interface Props {
  onSimulate: (data: RTSData) => void;
}

export default function RTSInputForm({ onSimulate }: Props) {
  const [formData, setFormData] = useState<RTSData>({
    tableName: "large_table",
    totalRows: 2300000000,
    currentIndex: "status, created_at",
    newIndex: "created_at, status",
    condition: "status != 'active'",
    selectivity: 0.05
  });

  const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value } = e.target;
    setFormData(prev => ({
      ...prev,
      [name]: name === "totalRows" || name === "selectivity" 
        ? (name === "totalRows" ? parseInt(value) || 0 : parseFloat(value) || 0)
        : value
    }));
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onSimulate(formData);
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-4">
      <div className="space-y-2">
        <Label htmlFor="tableName">Table Name</Label>
        <Input
          id="tableName"
          name="tableName"
          value={formData.tableName}
          onChange={handleChange}
          className="bg-gray-700 border-gray-600"
        />
      </div>

      <div className="space-y-2">
        <Label htmlFor="totalRows">Total Rows (e.g., 2.3B)</Label>
        <Input
          id="totalRows"
          name="totalRows"
          type="number"
          value={formData.totalRows}
          onChange={handleChange}
          className="bg-gray-700 border-gray-600"
        />
      </div>

      <div className="space-y-2">
        <Label htmlFor="currentIndex">Current Index Key Order</Label>
        <Input
          id="currentIndex"
          name="currentIndex"
          value={formData.currentIndex}
          onChange={handleChange}
          placeholder="(status, created_at)"
          className="bg-gray-700 border-gray-600"
        />
      </div>

      <div className="space-y-2">
        <Label htmlFor="newIndex">Proposed Index Key Order</Label>
        <Input
          id="newIndex"
          name="newIndex"
          value={formData.newIndex}
          onChange={handleChange}
          placeholder="(created_at, status)"
          className="bg-gray-700 border-gray-600"
        />
      </div>

      <div className="space-y-2">
        <Label htmlFor="condition">Query Predicate</Label>
        <Input
          id="condition"
          name="condition"
          value={formData.condition}
          onChange={handleChange}
          placeholder="status != 'active'"
          className="bg-gray-700 border-gray-600"
        />
      </div>

      <div className="space-y-2">
        <Label htmlFor="selectivity">Selectivity Estimate (0-1)</Label>
        <Input
          id="selectivity"
          name="selectivity"
          type="number"
          step="0.01"
          min="0"
          max="1"
          value={formData.selectivity}
          onChange={handleChange}
          className="bg-gray-700 border-gray-600"
        />
      </div>

      <Button type="submit" className="w-full bg-blue-600 hover:bg-blue-700">
        Simulate RTS
      </Button>
    </form>
  );
}