import React from "react";
import { Card, CardContent } from "../components/ui/card";
import { SimulationResult } from "../App";

interface Props {
  simulationResult: SimulationResult | null;
}

export default function EXPLAINPreview({ simulationResult }: Props) {
  if (!simulationResult) {
    return (
      <div className="text-center py-8 text-gray-500">
        <p>Enter production statistics to see EXPLAIN preview</p>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div>
        <h3 className="text-lg font-semibold mb-2 text-red-400">Current Plan</h3>
        <Card className="bg-gray-900 border-gray-700">
          <CardContent className="p-4">
            <pre className="text-sm text-red-300 whitespace-pre-wrap font-mono">
              {simulationResult.oldPlan}
            </pre>
          </CardContent>
        </Card>
      </div>

      <div>
        <div className="flex items-center justify-between mb-2">
          <h3 className="text-lg font-semibold text-green-400">Proposed Plan</h3>
          <span className="text-green-400 font-medium">
            {simulationResult.costReduction.toFixed(1)}% cost reduction
          </span>
        </div>
        <Card className="bg-gray-900 border-gray-700">
          <CardContent className="p-4">
            <pre className="text-sm text-green-300 whitespace-pre-wrap font-mono">
              {simulationResult.newPlan}
            </pre>
          </CardContent>
        </Card>
      </div>

      <div className="p-4 bg-gray-800 rounded-lg border border-gray-700">
        <h4 className="font-semibold mb-2 text-yellow-400">Analysis</h4>
        <p className="text-sm">
          New index <code className="bg-gray-700 px-1 rounded">{simulationResult.newIndex}</code> avoids full table scan.
        </p>
        <p className="text-sm mt-1">
          Estimated row reduction: <span className="font-mono">
            {simulationResult.rows.toLocaleString()} â†’ {Math.floor(simulationResult.rows * (1 - 0.05)).toLocaleString()}
          </span>
        </p>
      </div>
    </div>
  );
}