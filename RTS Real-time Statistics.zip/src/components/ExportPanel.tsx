import React, { useState } from "react";
import { Button } from "../components/ui/button";
import { Textarea } from "../components/ui/textarea";
import { useToast } from "../components/ui/use-toast";
import { Copy, Download } from "lucide-react";
import { SimulationResult } from "../App";

interface Props {
  simulationResult: SimulationResult | null;
}

export default function ExportPanel({ simulationResult }: Props) {
  const { toast } = useToast();
  const [copied, setCopied] = useState(false);

  if (!simulationResult) {
    return (
      <div className="text-center py-8 text-gray-500">
        <p>Simulate RTS to generate export data</p>
      </div>
    );
  }

  const exportData = JSON.stringify(simulationResult.exportData, null, 2);

  const copyToClipboard = () => {
    navigator.clipboard.writeText(exportData);
    setCopied(true);
    toast({
      title: "Copied to clipboard",
      description: "Paste into your non-prod environment",
    });
    setTimeout(() => setCopied(false), 2000);
  };

  const downloadFile = () => {
    const blob = new Blob([exportData], { type: "application/json" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = `${simulationResult.table}_rts.json`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
  };

  return (
    <div className="space-y-4">
      <Textarea
        value={exportData}
        readOnly
        className="min-h-[200px] font-mono text-sm bg-gray-900 border-gray-700"
      />
      
      <div className="flex flex-col sm:flex-row gap-2">
        <Button 
          onClick={copyToClipboard} 
          className="flex-1 bg-gray-700 hover:bg-gray-600"
        >
          <Copy className="mr-2 h-4 w-4" />
          {copied ? "Copied!" : "Copy to Clipboard"}
        </Button>
        
        <Button 
          onClick={downloadFile} 
          variant="outline"
          className="flex-1 border-gray-600 hover:bg-gray-700"
        >
          <Download className="mr-2 h-4 w-4" />
          Download JSON
        </Button>
      </div>
      
      <div className="text-sm text-gray-400 p-3 bg-gray-800 rounded border border-gray-700">
        <p className="font-medium mb-1">Usage Instructions:</p>
        <p>Apply to pg_stats with UPDATE statements in your non-prod environment.</p>
        <p className="mt-1">⚠️ Use only in non-production systems!</p>
      </div>
    </div>
  );
}