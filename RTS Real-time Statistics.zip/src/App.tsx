import React, { useState } from "react";
import RTSInputForm from "./components/RTSInputForm";
import EXPLAINPreview from "./components/EXPLAINPreview";
import ExportPanel from "./components/ExportPanel";
import { Card, CardContent, CardHeader, CardTitle } from "./components/ui/card";
import { Toaster } from "./components/ui/toaster";

export interface RTSData {
  tableName: string;
  totalRows: number;
  currentIndex: string;
  newIndex: string;
  condition: string;
  selectivity: number;
}

export interface SimulationResult {
  table: string;
  rows: number;
  currentIndex: string;
  newIndex: string;
  estimatedCost: number;
  costReduction: number;
  oldPlan: string;
  newPlan: string;
  exportData: {
    table: string;
    column: string;
    n_distinct: number;
    most_common_vals: string[];
    most_common_freqs: number[];
    hint: string;
  };
}

function App() {
  const [simulationResult, setSimulationResult] = useState<SimulationResult | null>(null);

  const handleSimulation = (data: RTSData) => {
    // Simulate RTS calculation
    const estimatedRows = Math.floor(data.totalRows * (1 - data.selectivity));
    const oldCost = data.totalRows * 0.1; // Simplified cost model
    const newCost = estimatedRows * 0.01; // Index scan cost
    const costReduction = ((oldCost - newCost) / oldCost) * 100;

    // Generate EXPLAIN plans
    const oldPlan = `Seq Scan on ${data.tableName}  (cost=0.00..${oldCost.toFixed(2)} rows=${data.totalRows} width=48)
  Filter: (${data.condition})`;

    const newPlan = `Index Scan using idx_${data.newIndex.replace(/[(), ]/g, "_")} on ${data.tableName}  (cost=0.42..${newCost.toFixed(2)} rows=${estimatedRows} width=48)
  Index Cond: (${data.condition})`;

    // Generate export data
    const exportData = {
      table: data.tableName,
      column: data.condition.split(" ")[0],
      n_distinct: -0.5,
      most_common_vals: ["active", "inactive"],
      most_common_freqs: [0.95, 0.04],
      hint: "Apply to pg_stats with UPDATE; use only in non-prod"
    };

    setSimulationResult({
      table: data.tableName,
      rows: data.totalRows,
      currentIndex: data.currentIndex,
      newIndex: data.newIndex,
      estimatedCost: newCost,
      costReduction,
      oldPlan,
      newPlan,
      exportData
    });
  };

  return (
    <div className="min-h-screen bg-gray-900 text-gray-100 p-4 md:p-8">
      <div className="max-w-6xl mx-auto">
        <header className="mb-8 text-center">
          <h1 className="text-3xl md:text-4xl font-bold bg-gradient-to-r from-blue-400 to-purple-500 text-transparent bg-clip-text">
            RTS Copier
          </h1>
          <p className="text-gray-400 mt-2">
            Real-Time Statistics Simulator for Non-Prod Environments
          </p>
        </header>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          <Card className="bg-gray-800 border-gray-700">
            <CardHeader>
              <CardTitle className="text-xl">Production Statistics</CardTitle>
            </CardHeader>
            <CardContent>
              <RTSInputForm onSimulate={handleSimulation} />
            </CardContent>
          </Card>

          <div className="space-y-6">
            <Card className="bg-gray-800 border-gray-700">
              <CardHeader>
                <CardTitle className="text-xl">Query Plan Preview</CardTitle>
              </CardHeader>
              <CardContent>
                <EXPLAINPreview simulationResult={simulationResult} />
              </CardContent>
            </Card>

            <Card className="bg-gray-800 border-gray-700">
              <CardHeader>
                <CardTitle className="text-xl">Export for Non-Prod</CardTitle>
              </CardHeader>
              <CardContent>
                <ExportPanel simulationResult={simulationResult} />
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
      <Toaster />
    </div>
  );
}

export default App;